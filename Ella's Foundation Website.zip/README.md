
  # Ella's Foundation Website

  This is a code bundle for Ella's Foundation Website. The original project is available at https://www.figma.com/design/zZnhlJUqknYIxOCV4zpVCu/Ella-s-Foundation-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  